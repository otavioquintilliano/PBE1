package br.com.bibliotecasenai.principal;

import br.com.bibliotecasenai.usuarios.Usuario;

public class Aplicacao {

	public static void main(String[] args) {
		Usuario usuario01 = new Usuario();
		usuario01.setCPF("0000005");
		usuario01.setlivrosEmprestados(10);

	}

}
