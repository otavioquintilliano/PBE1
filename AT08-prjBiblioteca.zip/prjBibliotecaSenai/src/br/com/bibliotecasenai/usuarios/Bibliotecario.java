package br.com.bibliotecasenai.usuarios;

public class Bibliotecario extends Pessoa{

	//Atributos
	private String Matricula;
	
	
	//Metodos
	
	public void realizarEmprestimo() {
	}
	
	public void realizarEmprestimo() {
	}
}
