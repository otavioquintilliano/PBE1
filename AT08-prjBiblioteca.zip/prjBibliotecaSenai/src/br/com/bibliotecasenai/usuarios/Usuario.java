package br.com.bibliotecasenai.usuarios;

public class Usuario extends Pessoa {

	
		private int CPF;
		private int livrosEmprestados;
		public int getCPF() {
			return CPF;
		}
		public void setCPF(int CPF) {
			CPF = CPF;
		}
		public int getLivrosEmprestados() {
			return livrosEmprestados;
		}
		public void setLivrosEmprestados(int livrosEmprestados) {
			this.livrosEmprestados = livrosEmprestados;
		}
		
		
		
		
}
