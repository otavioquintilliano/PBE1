package br.com.biblioteca.itens;

public class Emprestimos {

	
	//Atributos
	
	private int numerosEmprestimos;
	
	//Metodos
	
	public void emprestarLivros() {
	}
	
	public void getEmprestarLivros() {
	}
	
	public void devolverLivro() {
	}
	
	public void getDevolverLivro() {
	}
}
