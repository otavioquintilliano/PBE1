package prjExercicio04;

public class Veiculo {

	
	//Atributos
	
	String atributoMarca;
	String atributoModelo;
	int atributoVelocidade;
	
	//Construtores
	
	public Veiculo() {
	}
	
	public Veiculo(String parametroMarca, String parametroModelo, int parametroVelocidade) {
		this.atributoMarca = parametroMarca;
		this.atributoModelo = parametroModelo;
		this.atributoVelocidade = parametroVelocidade;
	}
	
	//Metodos
	
	public void acelerar() {
		if( atributoVelocidade == atributoVelocidade);
		
	}
}
