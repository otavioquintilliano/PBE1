package prjExercicio02;

import prjExercicio01.Carro;

public class aplicacao {

	public static void main(String[] args) {
		
		Livro QuartodeDespejo = new Livro();
		QuartodeDespejo.atributoTitulo ="Quarto de Despejo";
		QuartodeDespejo.atributoAutor = "Carolina Maria de Jesus";
		QuartodeDespejo.atributonumPaginas = 200;
		QuartodeDespejo.atributoPreco = 74;
		
		Livro Depoisdaqueleverao = new Livro();
		Depoisdaqueleverao.atributoTitulo = "Depois daquele verão ";
		Depoisdaqueleverao.atributoAutor = "Carley Fortune";
		Depoisdaqueleverao.atributonumPaginas = 288;
		Depoisdaqueleverao.atributoPreco = 37;
		
		Livro onix = new Livro();
		onix.atributoTitulo = "Encontros com a alma";
		onix.atributoAutor = "Barbara Hannah";
		onix.atributonumPaginas = 376;
		onix.atributoPreco = 98 ;


	}

}
