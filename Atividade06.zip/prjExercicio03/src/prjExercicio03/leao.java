package prjExercicio03;

public class leao extends Animal {

	
	//Metodos da Subclasse
		public void metodoCacar() {
			System.out.println(this.atributoNome + " está caçando!");
		}
}
