package prjExercicio03;

public class baleia extends Animal {

	
	//Metodos da Subclasse
		public void metodoNadar() {
			System.out.println(this.atributoNome + " está nadando!");
		}
}
