package prjExercicio01;

public class aplicacao {

	public static void main(String[] args) {
		
		Carro kicks = new Carro();
		kicks.atributoModelo = "Nissan Kicks";
		kicks.atributoMarca = "Nissan";
		kicks.atributoPlaca = "sue2a84r";
		kicks.atributoAno = 2014;
		
		Carro onix = new Carro();
		onix.atributoModelo = "Chevrolet Onix";
		onix.atributoMarca = "Chevrolet";
		onix.atributoPlaca = "qgu20n23";
		onix.atributoAno = 2019;

	}

}
